import parent.child1;


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child2 c2 = new child2();
		c2.details();
	}

}
