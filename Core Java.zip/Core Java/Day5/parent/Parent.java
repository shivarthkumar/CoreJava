package parent;

public class Parent {
	private static int a=10;
	static int b=20;
	protected static int c=30;
	public static int d=40;
}
