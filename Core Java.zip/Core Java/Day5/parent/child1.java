package parent;

public class child1 extends Parent{
	public static void main(String[] ar)
	{
		
		//System.out.println(a);
//		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}

}
