
public class sb_account extends Account{
	

	public boolean withdraw(float amt)
	{
		if(bal-amt >=500)
		{
			bal=bal-amt;
			return true;
		}
		return false;
	}
	
	 public void deposit(float amt) {
		 bal=bal+amt;
		
	}
}
