
public class Animal {
 int no_of_legs , length_of_leg , id;
 String gender,exsistence;
public Animal()
{
}
public Animal(int id , int no_of_legs , int length_of_leg , String existence , String gender)
 {
	this.id = id; 
	this.no_of_legs= no_of_legs;
	this.length_of_leg = length_of_leg;
	this.gender = gender;
	this.exsistence = existence;
 }
 
void display_details()
{
	System.out.println("No. of legs : "+no_of_legs + "  Id : "+id + "  Existence : "+exsistence + "  Gender : " +gender);
}
 void color()
 {
	 
 }

}
