
public class Account_with_getter {
	private int acc_no;
	private float acc_bal;
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public float getAcc_bal() {
		return acc_bal;
	}
	public void setAcc_bal(float acc_bal) {
		this.acc_bal = acc_bal;
	}
	
}
